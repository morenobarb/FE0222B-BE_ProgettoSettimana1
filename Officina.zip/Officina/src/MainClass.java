
public class MainClass {

	public static void main(String[] args) {
		Macchina m1 = new Macchina("FIAT Punto", 1200, "FE245SH", 8000, "BLU", 5);
		Macchina m2 = new Macchina("FIAT Panda", 1100, "GE145RH", 9500, "ROSSO", 5);
		Macchina m3 = new Macchina("FIAT 500", 1050, "FB645SI", 11000, "GRIGIO", 6);
		Macchina m4 = new Macchina("OPEL Corsa", 1700, "MB285SH", 12500, "NERO", 5);
		Macchina m5 = new Macchina("RENAULT Clio", 950, "UX555IH", 8750, "BIANCO", 5);

		Macchina[] auto = { m1, m2, m3, m4, m5 };

		infoMacchinaPiuCostosa(auto);
		infoMacchina( auto, "FB645SI");
        infoMacchinaColore(auto, "BLU");

	}

	static void infoMacchinaPiuCostosa(Macchina[] temp) {
		Macchina maxPrice = temp[0];
		for (int i = 0; i < temp.length; i++) {
			if (temp[i].getValore() > maxPrice.getValore()) {
				maxPrice = temp[i];
			}
		}
		
		System.out.println("Il veicolo piu' costoso: ");
		
		maxPrice.stampaInformazioni();
	}
	
	static void infoMacchina(Macchina[] temp, String targa) {
		Macchina myTarga = null;
		for (int i = 0; i < temp.length; i++) {
			if (temp[i].getTarga().toUpperCase().equals(targa.toUpperCase())) {
				myTarga=temp[i];
			}
			
			}System.out.println("********************");
		System.out.println("Il veicolo con targa: " + targa);
		myTarga.stampaInformazioni();
		}
	 
	
	static void infoMacchinaColore(Macchina[] temp, String colore) {
		Macchina myColor = null;
		for (int i = 0; i < temp.length; i++) {
			if (temp[i].getColore().toUpperCase().equals(colore)) {
				myColor=temp[i];
			}
			
			}
		System.out.println("********************");
		System.out.println("Il veicolo con il colore: " + colore);
		myColor.stampaInformazioni();
		}


}
	
	
	
	
	

