
public class Macchina {

	private String nome;
	private int cilindrata;
	private String targa;
	private int prezzo;
	private String colore;
	private int numeroMarce;
	private boolean motoreAcceso;
	private int marcia;

	public Macchina(String nome, int cilindrata, String targa, int prezzo, String colore, int numeroMarce) {
		this.nome = nome;
		this.cilindrata = cilindrata;
		this.targa = targa;
		this.prezzo = prezzo;
		this.colore = colore;
		this.numeroMarce = numeroMarce;
		this.motoreAcceso=false;
		this.marcia=0;
	}

	public void accendiMotore() {
		this.motoreAcceso = true;
	}

	public void spegniMotore() {
		this.marcia = 0;
		this.motoreAcceso = false;
	}

	public void cambiaMarcia(int numeroMarce) {
		// mi consente di fare un salto alla marcia
		// la marcia deve saltare dal volore al corrente a quello della marcia
		this.marcia = numeroMarce;

	}

	public void scalaMarcia() {
		if (this.marcia >= 1 && this.marcia <= this.numeroMarce) {
			this.marcia--;
		} else {
			System.out.println("Errore");
		}
	}

	
	public void aumentaMarcia() {
		if (this.marcia > 0 && this.marcia < this.numeroMarce) {
			this.marcia++;
		} else {
			System.out.println("Errore");
		}
	}

	public int getValore() {
		return this.prezzo;
	}

	public void stampaInformazioni() {
		System.out.println("Modello auto :" +this.nome );
		System.out.println("Cilindrata :" +this.cilindrata );
		System.out.println("Targa:" +this.getTarga() );
		System.out.println("Prezzo della vettura:" +this.prezzo );
		System.out.println("Colore auto:" +this.getColore() );
		System.out.println("Numero marce :" +this.numeroMarce);
	}

	public String getTarga() {
		return targa;
	}

	public String getColore() {
		return colore;
	}

	

}
